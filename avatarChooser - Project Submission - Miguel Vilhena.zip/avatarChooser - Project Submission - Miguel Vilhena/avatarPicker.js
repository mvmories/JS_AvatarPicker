(function ($) {

  $.fn.avatarPicker = function (options) {


    /**********************************************
    * SELECTED AVATAR
    */

    var selectedAvatar = $("<img>");

    // Checking local storage for selected avatar
    if (localStorage.hasOwnProperty('lastId') === false) {
      var avatarID = 1;
      selectedAvatar.attr("src", "img/img6.png");
    } else {
      avatarID = localStorage.lastId;
      selectedAvatar.attr("src", localStorage.lastSrc);
    }

    $(".selected-avatar").append(selectedAvatar);


    // Handling avatar list visibility
    selectedAvatar.click(function () {

      selectedAvatar.addClass("selectedAvatarBorder");
      $(".avatar-list-wrapper").fadeToggle();

    });




    /**********************************************
    * LIST OF AVATARS
    */

    var ul = $("<ul></ul>");

    // Printing avatar list from given array
    for (let i = 0; i < options.length; i++) {
      const option = options[i];
      var li = $("<li></li>");
      var img = $("<img>");
      var spinner = $("<div></div>");

      img.attr("src", option.src);
      spinner.addClass("spinner");
      spinner.hide();

      // After avatar selection  
      img.click(function () {
        avatarID = option.id;
        var currentimg = this;

        // Save selected avatar to local storage
        localStorage.lastId = option.id;
        localStorage.lastSrc = option.src;


        $(".spinner").hide();
        $(currentimg).siblings().show();

        // Simulate server response
        setTimeout(function () {
          resetHighlights(currentimg);
          selectedAvatar.removeClass("selectedAvatarBorder");
        }, 1200);

        function resetHighlights(el) {
          $(".avatar-list-wrapper ul li img").css('border', "none");
          $(".avatar-list-wrapper ul li img").removeAttr('style');
          $(".spinner").hide();
          $(el).css('border', "solid 3px #7aa1b2");
          selectedAvatar.attr("src", option.src);
        }

        // Close avatar list
        $('.avatar-list-wrapper').delay(1000).fadeOut(200).hide(0);
      });

      // Highlight default avatar
      if (option.id == avatarID) {
        img.css('border', '3px solid #7aa1b2');
      }

      li.append(img);
      li.append(spinner);
      ul.append(li);
    }

    $(".avatar-list-wrapper").append(ul);

    // Hide avatar list by default
    $('.avatar-list-wrapper').fadeOut();




    /**********************************************
    * AVATAR-LIST-WRAPPER - CLICK OUTSIDE FUNCTION
    */

    $(document).mouseup(function (e) {
      var wrapper = $('.avatar-list-wrapper');


      if (!wrapper.is(e.target) && wrapper.has(e.target).length === 0) {
        wrapper.fadeOut();
        selectedAvatar.removeClass("selectedAvatarBorder");
      }
    });
  };

})(jQuery);
